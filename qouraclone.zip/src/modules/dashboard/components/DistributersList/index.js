import React from "react";
import SettlementManagementTable from "./Table";

function DistributerList() {
  return (
    <SettlementManagementTable />
  );
}

export default DistributerList;
