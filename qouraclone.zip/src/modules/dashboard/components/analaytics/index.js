import React from "react";
import Charts from "./Chart"
function Dashboard() {
  return <div>
    <Charts />
  </div>;
}

export default Dashboard;
