import React, { Fragment } from "react";
import TableWrapper from "../../../../../../common/Tables";

function SettlementManagementTable() {
  return (
    <Fragment>
      <TableWrapper text={"users"} />
    </Fragment>
  );
}

export default SettlementManagementTable;
