import React, { Fragment } from "react";
import TableWrapper from "../../../../../common/Tables";

function ManagementTable() {
  return (
    <Fragment>
      <TableWrapper text={"USER"} />
    </Fragment>
  );
}

export default ManagementTable;
