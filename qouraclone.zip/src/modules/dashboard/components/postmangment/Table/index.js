import React, { Fragment } from "react";
import TableWrapper from "../../../../../common/Tables";

function SettlementManagementTable() {
  return (
    <Fragment>
      <TableWrapper text={"POSTS"} />
    </Fragment>
  );
}

export default SettlementManagementTable;
