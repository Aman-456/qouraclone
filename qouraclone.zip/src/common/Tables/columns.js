import { Avatar, Col, Row, Typography } from "antd";
import { Tooltip } from "chart.js";
import { TransparentBtnsAction } from "../Buttons";

