import React from "react";
import ManagementTable from "./Table";

function PostMangment() {
  return (
    <ManagementTable />
  );
}

export default PostMangment;
